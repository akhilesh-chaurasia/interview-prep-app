 
import { RouterProvider } from "react-router"
import {router} from "./app.route.jsx"
import { AuthProvider } from "./features/auth/auth.context.jsx"
import { InterviewProvider } from "./features/interviews/interview.context.jsx"

function App() {

  return (
    <AuthProvider>
      <InterviewProvider>
      <RouterProvider router = {router}/>
      </InterviewProvider>
    </AuthProvider>
    
  )
}

export default App
