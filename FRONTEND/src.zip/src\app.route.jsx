import { createBrowserRouter } from "react-router";
import Login from "./features/auth/pages/Login";
import Register from "./features/auth/pages/Register";
import Protected from "./features/auth/components/Protected";
import Home from "./features/interviews/pages/Home";
import Interview from "./features/interviews/pages/Dashboard/InterviewDashboard";
import InterviewSession from './features/interviews/pages/Session/InterviewSession'

export const router = createBrowserRouter([
    {
        path: "/login",
        element: <Login />
    },
    {
        path: "/register",
        element: <Register />
    },
    {
        path: "/",
        element: <Protected><Home /></Protected>
    },
    {
        path:"/interview/:interviewId",
        element: <Protected><Interview /></Protected>
    },

    {
        path: "/interview/session/:sessionId",
        element: <Protected><InterviewSession /></Protected>
    }
])